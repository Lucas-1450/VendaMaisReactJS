<?php
    $arr_data = [];
    $arr_data['sc'] = "v9";
    $arr_data['sc_version'] = "9.10.019";
    $arr_data['sc_build'] = "3";
    $arr_data['prod_version'] = "1.0.001";
    $arr_data['prod_build'] = "6";
    $arr_data['initial'] = "fat126_5.php";
    $arr_data['group'] = "GOL";
    $arr_data['apl'] = "fat126_5";
    $arr_data['description'] = "F126 - Fat - Venda - Item - Atualizar";
    $arr_data['status'] = "SIM";
    $arr_data['type'] = "form";
    $arr_data['friendly_url'] = "fat126_5";
    $arr_data['md5'] = "LigMd5";
